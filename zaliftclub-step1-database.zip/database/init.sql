-- ============================================
-- ZA LIFT CLUB — DATABASE SCHEMA
-- PostgreSQL 15+
-- ============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─────────────────────────────────────────
-- USERS
-- ─────────────────────────────────────────
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20) UNIQUE NOT NULL,
    password_hash VARCHAR(255),
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    profile_picture VARCHAR(500),
    date_of_birth DATE,
    gender VARCHAR(20),
    user_type VARCHAR(20) DEFAULT 'passenger' CHECK (user_type IN ('passenger', 'driver', 'admin')),
    is_verified BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    is_banned BOOLEAN DEFAULT FALSE,
    rating DECIMAL(3,2) DEFAULT 0,
    total_rides INT DEFAULT 0,
    verified_badge BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_type ON users(user_type);

-- ─────────────────────────────────────────
-- OTP CODES
-- ─────────────────────────────────────────
CREATE TABLE otp_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    identifier VARCHAR(255) NOT NULL,
    code VARCHAR(6) NOT NULL,
    purpose VARCHAR(50) NOT NULL,
    expires_at TIMESTAMP NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_otp_identifier ON otp_codes(identifier);
CREATE INDEX idx_otp_expires ON otp_codes(expires_at);

-- ─────────────────────────────────────────
-- USER VERIFICATIONS
-- ─────────────────────────────────────────
CREATE TABLE user_verifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    verification_type VARCHAR(50) NOT NULL,
    verification_value TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_verifications_user ON user_verifications(user_id);

-- ─────────────────────────────────────────
-- DRIVER PROFILES
-- ─────────────────────────────────────────
CREATE TABLE driver_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    license_number VARCHAR(50),
    license_expiry DATE,
    license_photo_front VARCHAR(500),
    license_photo_back VARCHAR(500),
    id_number VARCHAR(50),
    id_photo VARCHAR(500),
    proof_of_address VARCHAR(500),
    is_license_verified BOOLEAN DEFAULT FALSE,
    is_background_checked BOOLEAN DEFAULT FALSE,
    approval_status VARCHAR(20) DEFAULT 'pending' CHECK (approval_status IN ('pending', 'approved', 'rejected')),
    approved_at TIMESTAMP,
    rejection_reason TEXT,
    total_earnings DECIMAL(10,2) DEFAULT 0,
    completed_trips INT DEFAULT 0,
    cancellation_rate DECIMAL(5,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_driver_user ON driver_profiles(user_id);
CREATE INDEX idx_driver_approval ON driver_profiles(approval_status);

-- ─────────────────────────────────────────
-- VEHICLES
-- ─────────────────────────────────────────
CREATE TABLE vehicles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    driver_id UUID REFERENCES driver_profiles(id) ON DELETE CASCADE,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    color VARCHAR(30),
    registration_number VARCHAR(20) UNIQUE NOT NULL,
    registration_photo VARCHAR(500),
    insurance_document VARCHAR(500),
    vehicle_photo_front VARCHAR(500),
    vehicle_photo_back VARCHAR(500),
    vehicle_photo_interior VARCHAR(500),
    is_verified BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'active',
    luggage_capacity INT DEFAULT 2,
    has_air_conditioning BOOLEAN DEFAULT TRUE,
    has_usb_ports BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_vehicles_driver ON vehicles(driver_id);

-- ─────────────────────────────────────────
-- TRIPS
-- ─────────────────────────────────────────
CREATE TABLE trips (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    driver_id UUID REFERENCES driver_profiles(id) ON DELETE CASCADE,
    vehicle_id UUID REFERENCES vehicles(id),
    departure_city VARCHAR(100) NOT NULL,
    departure_location VARCHAR(255) NOT NULL,
    departure_latitude DECIMAL(10,8),
    departure_longitude DECIMAL(11,8),
    destination_city VARCHAR(100) NOT NULL,
    destination_location VARCHAR(255) NOT NULL,
    destination_latitude DECIMAL(10,8),
    destination_longitude DECIMAL(11,8),
    departure_date DATE NOT NULL,
    departure_time TIME NOT NULL,
    available_seats INT NOT NULL,
    total_seats INT NOT NULL,
    price_per_seat DECIMAL(10,2) NOT NULL,
    luggage_allowed BOOLEAN DEFAULT TRUE,
    smoking_allowed BOOLEAN DEFAULT FALSE,
    pets_allowed BOOLEAN DEFAULT FALSE,
    women_only BOOLEAN DEFAULT FALSE,
    flexible_time BOOLEAN DEFAULT FALSE,
    additional_notes TEXT,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'fully_booked', 'completed', 'cancelled')),
    distance_km DECIMAL(10,2),
    estimated_duration_minutes INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_trips_departure ON trips(departure_city);
CREATE INDEX idx_trips_destination ON trips(destination_city);
CREATE INDEX idx_trips_date ON trips(departure_date);
CREATE INDEX idx_trips_status ON trips(status);
-- Optimized search index
CREATE INDEX idx_trips_search ON trips(departure_city, destination_city, departure_date, status)
    WHERE status = 'active';

-- ─────────────────────────────────────────
-- BOOKINGS
-- ─────────────────────────────────────────
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trip_id UUID REFERENCES trips(id) ON DELETE CASCADE,
    passenger_id UUID REFERENCES users(id) ON DELETE CASCADE,
    seats_booked INT NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    commission_amount DECIMAL(10,2),
    driver_payout DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'confirmed', 'completed', 'cancelled', 'rejected', 'failed')),
    pickup_location VARCHAR(255),
    special_requests TEXT,
    cancelled_by UUID REFERENCES users(id),
    cancellation_reason TEXT,
    cancelled_at TIMESTAMP,
    confirmed_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bookings_trip ON bookings(trip_id);
CREATE INDEX idx_bookings_passenger ON bookings(passenger_id);
CREATE INDEX idx_bookings_status ON bookings(status, created_at DESC)
    WHERE status IN ('pending', 'confirmed');

-- ─────────────────────────────────────────
-- PAYMENTS
-- ─────────────────────────────────────────
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id),
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(255),
    payment_gateway VARCHAR(50),
    gateway_response JSONB,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'success', 'failed', 'refunded')),
    refund_amount DECIMAL(10,2),
    refunded_at TIMESTAMP,
    paid_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_status ON payments(status);

-- ─────────────────────────────────────────
-- REVIEWS
-- ─────────────────────────────────────────
CREATE TABLE reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id UUID REFERENCES bookings(id) ON DELETE CASCADE UNIQUE,
    reviewer_id UUID REFERENCES users(id),
    reviewee_id UUID REFERENCES users(id),
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    punctuality_rating INT CHECK (punctuality_rating >= 1 AND punctuality_rating <= 5),
    safety_rating INT CHECK (safety_rating >= 1 AND safety_rating <= 5),
    communication_rating INT CHECK (communication_rating >= 1 AND communication_rating <= 5),
    cleanliness_rating INT CHECK (cleanliness_rating >= 1 AND cleanliness_rating <= 5),
    comment TEXT,
    response TEXT,
    is_flagged BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reviews_reviewee ON reviews(reviewee_id);
CREATE INDEX idx_reviews_rating ON reviews(rating);

-- ─────────────────────────────────────────
-- MESSAGES
-- ─────────────────────────────────────────
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id VARCHAR(255) NOT NULL,
    sender_id UUID REFERENCES users(id),
    receiver_id UUID REFERENCES users(id),
    message TEXT,
    message_type VARCHAR(20) DEFAULT 'text',
    media_url VARCHAR(500),
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_messages_conversation ON messages(conversation_id, created_at DESC);

-- ─────────────────────────────────────────
-- RIDE REQUESTS (Passenger Posts)
-- ─────────────────────────────────────────
CREATE TABLE ride_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    passenger_id UUID REFERENCES users(id) ON DELETE CASCADE,
    from_city VARCHAR(100) NOT NULL,
    from_location VARCHAR(255),
    to_city VARCHAR(100) NOT NULL,
    to_location VARCHAR(255),
    travel_date DATE NOT NULL,
    flexible_date BOOLEAN DEFAULT FALSE,
    budget DECIMAL(10,2),
    passengers_count INT DEFAULT 1,
    notes TEXT,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_requests_cities ON ride_requests(from_city, to_city);
CREATE INDEX idx_requests_date ON ride_requests(travel_date);

-- ─────────────────────────────────────────
-- NOTIFICATIONS
-- ─────────────────────────────────────────
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT,
    data JSONB,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_user ON notifications(user_id, is_read);

-- ─────────────────────────────────────────
-- SUPPORT TICKETS
-- ─────────────────────────────────────────
CREATE TABLE support_tickets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    ticket_number VARCHAR(50) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    priority VARCHAR(20) DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
    status VARCHAR(20) DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'resolved', 'closed')),
    assigned_to UUID REFERENCES users(id),
    resolved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tickets_user ON support_tickets(user_id);
CREATE INDEX idx_tickets_status ON support_tickets(status);

-- ─────────────────────────────────────────
-- DRIVER EARNINGS
-- ─────────────────────────────────────────
CREATE TABLE driver_earnings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    driver_id UUID REFERENCES driver_profiles(id),
    booking_id UUID REFERENCES bookings(id),
    amount DECIMAL(10,2) NOT NULL,
    commission_deducted DECIMAL(10,2),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'available', 'paid')),
    payout_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_earnings_driver ON driver_earnings(driver_id, status);

-- ─────────────────────────────────────────
-- PLATFORM SETTINGS
-- ─────────────────────────────────────────
CREATE TABLE platform_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value JSONB NOT NULL,
    description TEXT,
    updated_by UUID REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────
-- AUDIT LOGS
-- ─────────────────────────────────────────
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_user ON audit_logs(user_id);
CREATE INDEX idx_audit_entity ON audit_logs(entity_type, entity_id);

-- ─────────────────────────────────────────
-- DEFAULT SETTINGS
-- ─────────────────────────────────────────
INSERT INTO platform_settings (setting_key, setting_value, description) VALUES
('commission_rate',  '{"percentage": 15.0}',                        'Platform commission %'),
('min_withdrawal',   '{"amount": 100.0}',                           'Minimum withdrawal (ZAR)'),
('cancellation_fee', '{"amount": 25.0}',                            'Cancellation fee (ZAR)'),
('referral_bonus',   '{"driver": 50.0, "passenger": 25.0}',         'Referral bonus amounts (ZAR)'),
('max_seats',        '{"value": 8}',                                'Max seats per trip'),
('supported_cities', '{"cities": ["Cape Town","Johannesburg","Durban","Pretoria","Port Elizabeth","Bloemfontein","Nelspruit","East London","Polokwane","Kimberley"]}', 'Supported SA cities');

-- ─────────────────────────────────────────
-- SEED: Admin user (password: Admin123!@#)
-- bcrypt hash of Admin123!@#
-- ─────────────────────────────────────────
INSERT INTO users (email, phone, password_hash, first_name, last_name, user_type, is_verified, is_active)
VALUES (
    'admin@zaliftclub.co.za',
    '+27800000000',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/lewdBHC.A3xXoHFNS',
    'ZA Lift',
    'Admin',
    'admin',
    true,
    true
);

-- ─────────────────────────────────────────
-- MATERIALIZED VIEW: Daily Analytics
-- ─────────────────────────────────────────
CREATE MATERIALIZED VIEW daily_analytics AS
SELECT
    DATE(b.created_at)                                              AS date,
    COUNT(DISTINCT b.passenger_id)                                  AS unique_passengers,
    COUNT(DISTINCT t.driver_id)                                     AS unique_drivers,
    COUNT(b.id)                                                     AS total_bookings,
    SUM(CASE WHEN b.status = 'completed' THEN 1 ELSE 0 END)        AS completed_bookings,
    SUM(CASE WHEN b.status = 'cancelled' THEN 1 ELSE 0 END)        AS cancelled_bookings,
    COALESCE(SUM(b.total_amount), 0)                               AS gross_revenue,
    COALESCE(SUM(b.commission_amount), 0)                          AS commission_earned
FROM bookings b
JOIN trips t ON t.id = b.trip_id
GROUP BY DATE(b.created_at);

CREATE UNIQUE INDEX idx_daily_analytics_date ON daily_analytics(date);

-- Done!
SELECT 'ZA Lift Club database initialized successfully!' AS status;
