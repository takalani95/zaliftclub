# ZA Lift Club 🇿🇦

> Safe & affordable long-distance ride-sharing across South Africa

## Project Structure

```
zaliftclub/
├── database/        ← SQL schema & migrations
├── backend/         ← NestJS API (Step 2)
├── frontend/        ← Next.js web app (Step 3)
├── mobile/          ← React Native app (Step 4)
└── docker/          ← Docker Compose configs
```

## Step 1 — Start the Database (Do This Now)

### Prerequisites
- Docker Desktop running on Windows ✅
- Node.js installed ✅

### Commands (run in PowerShell or CMD)

```powershell
# 1. Clone or create the project folder
cd C:\Projects
mkdir zaliftclub
cd zaliftclub

# 2. Copy all project files here (from Claude's output)

# 3. Start PostgreSQL + Redis
cd docker
docker-compose -f docker-compose.dev.yml up -d

# 4. Verify containers are running
docker ps
```

### What starts:
| Service    | URL                          | Credentials                          |
|------------|------------------------------|--------------------------------------|
| PostgreSQL | localhost:5432               | user: zalift_user / zalift_dev_password |
| Redis      | localhost:6379               | password: zalift_redis_pass          |
| pgAdmin    | http://localhost:5050        | admin@zaliftclub.co.za / admin123    |

### Verify Database
Open pgAdmin at http://localhost:5050 and connect with:
- Host: postgres
- Port: 5432
- Database: zaliftclub
- Username: zalift_user
- Password: zalift_dev_password

You should see all tables created automatically from `database/init.sql`

---

## Next Steps
- ✅ Step 1: Database (current)
- ⏳ Step 2: Backend NestJS API
- ⏳ Step 3: Frontend Next.js
- ⏳ Step 4: Mobile React Native
